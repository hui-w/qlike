function() {
	if (!module) {
		var module = {};
	}