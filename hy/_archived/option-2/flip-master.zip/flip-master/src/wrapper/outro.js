	module.exports.identifier = {
		name:'__NAME__',
		type:'__TYPE__'
	};
    return module.exports;
}